// Admin Panel JavaScript

document.addEventListener('DOMContentLoaded', function() {
    if (!isAdmin()) {
        window.location.href = '../index.html';
        return;
    }
    
    loadDashboardStats();
    loadMovies();
    loadTheaters();
    loadSnacks();
    loadBookings();
    setupEventListeners();
});

function setupEventListeners() {
    // Tab navigation
    document.querySelectorAll('.tab-btn').forEach(button => {
        button.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            switchTab(tabId);
        });
    });
    
    // Form submissions
    document.getElementById('addMovieForm').addEventListener('submit', addMovie);
    
    // Booking filters
    document.getElementById('bookingStatusFilter').addEventListener('change', filterBookings);
    document.getElementById('bookingDateFilter').addEventListener('change', filterBookings);
}

function loadDashboardStats() {
    const movies = getMovies();
    const theaters = getTheaters();
    const bookings = getBookings();
    
    // Total movies
    document.getElementById('totalMovies').textContent = movies.length;
    
    // Total theaters
    document.getElementById('totalTheaters').textContent = theaters.length;
    
    // Total bookings
    document.getElementById('totalBookings').textContent = bookings.length;
    
    // Total revenue
    const totalRevenue = bookings.reduce((sum, booking) => sum + booking.totalAmount, 0);
    document.getElementById('totalRevenue').textContent = `₹${totalRevenue}`;
}

function loadMovies() {
    const movies = getMovies();
    const container = document.getElementById('moviesList');
    
    if (movies.length === 0) {
        container.innerHTML = '<p class="empty-message">No movies added yet</p>';
        return;
    }
    
    container.innerHTML = movies.map(movie => `
        <div class="item-card">
            <img src="${movie.poster}" alt="${movie.title}" class="item-image">
            <div class="item-content">
                <h3>${movie.title}</h3>
                <div class="item-meta">
                    <span><i class="fas fa-star"></i> ${movie.rating}/10</span>
                    <span><i class="fas fa-clock"></i> ${movie.duration}</span>
                    <span><i class="fas fa-tags"></i> ${movie.genre}</span>
                    <span><i class="fas fa-rupee-sign"></i> ₹${movie.price}</span>
                </div>
                <p>${movie.description.substring(0, 100)}...</p>
                <div class="item-actions">
                    <button class="btn btn-primary" onclick="editMovie(${movie.id})">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button class="btn" style="background: #e74c3c; color: white;" onclick="deleteMovie(${movie.id})">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

function loadTheaters() {
    const theaters = getTheaters();
    const container = document.getElementById('theatersList');
    
    if (theaters.length === 0) {
        container.innerHTML = '<p class="empty-message">No theaters added yet</p>';
        return;
    }
    
    container.innerHTML = theaters.map(theater => `
        <div class="item-card">
            <img src="${theater.image}" alt="${theater.name}" class="item-image">
            <div class="item-content">
                <h3>${theater.name}</h3>
                <div class="item-meta">
                    <span><i class="fas fa-map-marker-alt"></i> ${theater.location}</span>
                    <span><i class="fas fa-film"></i> ${theater.movies.length} Movies</span>
                </div>
                <p>Facilities: ${theater.facilities.join(', ')}</p>
                <div class="item-actions">
                    <button class="btn btn-primary" onclick="editTheater(${theater.id})">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button class="btn" style="background: #e74c3c; color: white;" onclick="deleteTheater(${theater.id})">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

function loadSnacks() {
    const snacks = getSnacks();
    const container = document.getElementById('snacksList');
    
    if (snacks.length === 0) {
        container.innerHTML = '<p class="empty-message">No snacks added yet</p>';
        return;
    }
    
    container.innerHTML = snacks.map(snack => `
        <div class="item-card">
            <img src="${snack.image}" alt="${snack.name}" class="item-image">
            <div class="item-content">
                <h3>${snack.name}</h3>
                <div class="item-meta">
                    <span><i class="fas fa-rupee-sign"></i> ₹${snack.price}</span>
                    <span><i class="fas fa-tags"></i> ${snack.category}</span>
                </div>
                <div class="item-actions">
                    <button class="btn btn-primary" onclick="editSnack(${snack.id})">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button class="btn" style="background: #e74c3c; color: white;" onclick="deleteSnack(${snack.id})">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

function loadBookings() {
    const bookings = getBookings();
    const tbody = document.getElementById('bookingsTableBody');
    
    if (bookings.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="empty-message">No bookings yet</td></tr>';
        return;
    }
    
    tbody.innerHTML = bookings.map(booking => `
        <tr>
            <td>${booking.id.substring(0, 8)}...</td>
            <td>${booking.movieTitle}</td>
            <td>${booking.theaterName}</td>
            <td>${booking.showtime}</td>
            <td>${booking.seats.length}</td>
            <td>₹${booking.totalAmount}</td>
            <td><span class="status-badge status-${booking.status}">${booking.status}</span></td>
            <td>
                <button class="btn btn-small" onclick="viewBookingDetails('${booking.id}')">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="btn btn-small" style="background: #ffc107; color: #212529;" onclick="updateBookingStatus('${booking.id}')">
                    <i class="fas fa-sync"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

function switchTab(tabId) {
    // Hide all tab contents
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    
    // Remove active class from all tabs
    document.querySelectorAll('.tab-btn').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Show selected tab content
    document.getElementById(`${tabId}-tab`).classList.add('active');
    
    // Add active class to clicked tab
    document.querySelector(`[data-tab="${tabId}"]`).classList.add('active');
}

// Movie Management Functions
function openAddMovieModal() {
    document.getElementById('addMovieModal').style.display = 'flex';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

function addMovie(e) {
    e.preventDefault();
    
    const form = e.target;
    const formData = new FormData(form);
    
    const movies = getMovies();
    const newMovie = {
        id: Date.now(),
        title: formData.get('title'),
        genre: formData.get('genre'),
        duration: formData.get('duration'),
        rating: parseFloat(formData.get('rating')),
        poster: formData.get('poster'),
        backdrop: formData.get('backdrop'),
        description: formData.get('description'),
        price: parseFloat(formData.get('price')),
        showtimes: ["10:00 AM", "1:30 PM", "5:00 PM", "8:30 PM"],
        cast: ["Actor 1", "Actor 2", "Actor 3"],
        director: "Director Name",
        releaseDate: new Date().toISOString().split('T')[0],
        trailer: "https://www.youtube.com/embed/example"
    };
    
    movies.push(newMovie);
    saveMovies(movies);
    
    alert('Movie added successfully!');
    closeModal('addMovieModal');
    form.reset();
    loadMovies();
    loadDashboardStats();
}

function editMovie(movieId) {
    const movies = getMovies();
    const movie = movies.find(m => m.id == movieId);
    if (movie) {
        alert(`Edit movie: ${movie.title}\nThis would open an edit form in a real implementation.`);
    }
}

function deleteMovie(movieId) {
    if (confirm('Are you sure you want to delete this movie?')) {
        const movies = getMovies();
        const updatedMovies = movies.filter(m => m.id != movieId);
        saveMovies(updatedMovies);
        alert('Movie deleted successfully!');
        loadMovies();
        loadDashboardStats();
    }
}

// Theater Management Functions
function openAddTheaterModal() {
    alert('Add theater functionality would be implemented here.');
}

function editTheater(theaterId) {
    alert('Edit theater functionality would be implemented here.');
}

function deleteTheater(theaterId) {
    if (confirm('Are you sure you want to delete this theater?')) {
        const theaters = getTheaters();
        const updatedTheaters = theaters.filter(t => t.id != theaterId);
        saveTheaters(updatedTheaters);
        alert('Theater deleted successfully!');
        loadTheaters();
        loadDashboardStats();
    }
}

// Snack Management Functions
function openAddSnackModal() {
    alert('Add snack functionality would be implemented here.');
}

function editSnack(snackId) {
    alert('Edit snack functionality would be implemented here.');
}

function deleteSnack(snackId) {
    if (confirm('Are you sure you want to delete this snack?')) {
        const snacks = getSnacks();
        const updatedSnacks = snacks.filter(s => s.id != snackId);
        saveSnacks(updatedSnacks);
        alert('Snack deleted successfully!');
        loadSnacks();
    }
}

// Booking Management Functions
function filterBookings() {
    // Implementation for filtering bookings
    console.log('Filtering bookings...');
}

function viewBookingDetails(bookingId) {
    const bookings = getBookings();
    const booking = bookings.find(b => b.id === bookingId);
    if (booking) {
        let details = `Booking Details:\n\n`;
        details += `ID: ${booking.id}\n`;
        details += `Movie: ${booking.movieTitle}\n`;
        details += `Theater: ${booking.theaterName}\n`;
        details += `Showtime: ${booking.showtime}\n`;
        details += `Seats: ${booking.seats.map(s => s.id).join(', ')}\n`;
        details += `Total: $${booking.totalAmount.toFixed(2)}\n`;
        details += `Status: ${booking.status}\n`;
        alert(details);
    }
}

function updateBookingStatus(bookingId) {
    const newStatus = prompt('Enter new status (confirmed/completed/cancelled):');
    if (newStatus && ['confirmed', 'completed', 'cancelled'].includes(newStatus)) {
        const bookings = getBookings();
        const booking = bookings.find(b => b.id === bookingId);
        if (booking) {
            booking.status = newStatus;
            saveBookings(bookings);
            alert('Booking status updated successfully!');
            loadBookings();
        }
    } else if (newStatus) {
        alert('Invalid status. Please use: confirmed, completed, or cancelled');
    }
}

// Settings Functions
function updateParkingSettings() {
    const carPrice = document.getElementById('carParkingPrice').value;
    const bikePrice = document.getElementById('bikeParkingPrice').value;
    
    const parking = getParking();
    parking.car.price = parseFloat(carPrice);
    parking.bike.price = parseFloat(bikePrice);
    
    saveParking(parking);
    alert('Parking settings updated successfully!');
}

function addUpcomingMovie() {
    const title = document.getElementById('upcomingMovieTitle').value;
    const date = document.getElementById('upcomingMovieDate').value;
    
    if (!title || !date) {
        alert('Please fill in all fields');
        return;
    }
    
    const upcomingMovies = getUpcomingMovies();
    const newMovie = {
        id: Date.now(),
        title: title,
        releaseDate: date,
        poster: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
        description: "Coming soon to theaters"
    };
    
    upcomingMovies.push(newMovie);
    saveUpcomingMovies(upcomingMovies);
    
    alert('Upcoming movie added successfully!');
    document.getElementById('upcomingMovieTitle').value = '';
    document.getElementById('upcomingMovieDate').value = '';
}

// Admin Authentication
function logoutAdminPanel() {
    if (confirm('Are you sure you want to logout?')) {
        logoutAdmin();
        window.location.href = '../index.html';
    }
}