// History Page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    loadBookingHistory();
    setupEventListeners();
});

function loadBookingHistory() {
    const bookings = getBookings();
    
    if (bookings.length === 0) {
        displayEmptyState();
        return;
    }
    
    // Separate upcoming and past bookings
    const now = new Date();
    const upcoming = [];
    const past = [];
    
    bookings.forEach(booking => {
        const showDate = getShowDate(booking);
        if (showDate >= now) {
            upcoming.push(booking);
        } else {
            past.push(booking);
        }
    });
    
    // Sort by date
    upcoming.sort((a, b) => getShowDate(a) - getShowDate(b));
    past.sort((a, b) => getShowDate(b) - getShowDate(a)); // Newest first
    
    displayBookings(upcoming, 'upcomingBookings');
    displayBookings(past, 'pastBookings');
}

function getShowDate(booking) {
    // This is a simplified implementation
    // In a real app, you'd parse the actual showtime date
    return new Date(booking.date);
}

function displayBookings(bookings, containerId) {
    const container = document.getElementById(containerId);
    
    if (bookings.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-ticket-alt"></i>
                <h3>No bookings found</h3>
                <p>${containerId === 'upcomingBookings' ? 'You have no upcoming bookings' : 'You have no past bookings'}</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = bookings.map(booking => {
        const movie = getMovieById(booking.movieId);
        return `
            <div class="booking-card">
                <div class="booking-header">
                    <div class="booking-status status-${booking.status}">
                        ${booking.status.toUpperCase()}
                    </div>
                    <div class="booking-movie">
                        <img src="${movie ? movie.poster : ''}" alt="${booking.movieTitle}" class="booking-poster">
                        <div class="booking-title">
                            <h3>${booking.movieTitle}</h3>
                            <div class="booking-meta">
                                <span><i class="fas fa-landmark"></i> ${booking.theaterName}</span>
                                <span><i class="fas fa-clock"></i> ${booking.showtime}</span>
                                <span><i class="fas fa-calendar"></i> ${new Date(booking.date).toLocaleDateString()}</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="booking-details">
                    <div class="booking-info">
                        <div class="info-item">
                            <i class="fas fa-couch"></i>
                            <span>Seats: ${booking.seats.map(s => s.id).join(', ')}</span>
                        </div>
                        <div class="info-item">
                            <i class="fas fa-ticket-alt"></i>
                            <span>Tickets: ${booking.seats.length}</span>
                        </div>
                        ${booking.snacks && booking.snacks.length > 0 ? `
                        <div class="info-item">
                            <i class="fas fa-popcorn"></i>
                            <span>Snacks: ${booking.snacks.reduce((sum, s) => sum + s.quantity, 0)} items</span>
                        </div>
                        ` : ''}
                        <div class="info-item">
                            <i class="fas fa-receipt"></i>
                            <span>Total: ₹${booking.totalAmount}</span>
                        </div>
                    </div>
                    
                    <div class="booking-actions">
                        <button class="btn btn-primary btn-small" onclick="viewTicket('${booking.id}')">
                            <i class="fas fa-eye"></i> View Ticket
                        </button>
                        ${booking.status === 'confirmed' ? `
                        <button class="btn btn-small" onclick="downloadReceipt('${booking.id}')">
                            <i class="fas fa-download"></i> Receipt
                        </button>
                        <button class="btn btn-small" style="background: #ffc107; color: #212529;" onclick="cancelBooking('${booking.id}')">
                            <i class="fas fa-times"></i> Cancel
                        </button>
                        ` : ''}
                        ${booking.status === 'completed' ? `
                        <button class="btn btn-small" style="background: #17a2b8; color: white;" onclick="writeReview('${booking.movieId}')">
                            <i class="fas fa-star"></i> Review Movie
                        </button>
                        ` : ''}
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

function displayEmptyState() {
    const upcomingContainer = document.getElementById('upcomingBookings');
    const pastContainer = document.getElementById('pastBookings');
    
    upcomingContainer.innerHTML = `
        <div class="empty-state">
            <i class="fas fa-calendar-check"></i>
            <h3>No Upcoming Bookings</h3>
            <p>Book your next movie experience today!</p>
            <button class="btn btn-primary" onclick="window.location.href='index.html'" style="margin-top: 1rem;">
                <i class="fas fa-search"></i> Browse Movies
            </button>
        </div>
    `;
    
    pastContainer.innerHTML = `
        <div class="empty-state">
            <i class="fas fa-history"></i>
            <h3>No Booking History</h3>
            <p>Your past movie bookings will appear here</p>
        </div>
    `;
}

function setupEventListeners() {
    // Admin login button
    document.getElementById('adminLoginBtn').addEventListener('click', function() {
        if (isAdmin()) {
            window.location.href = 'admin/index.html';
        } else {
            showAdminLogin();
        }
    });
    
    // Filter event listeners
    document.getElementById('statusFilter').addEventListener('change', filterBookings);
    document.getElementById('dateFilter').addEventListener('change', sortBookings);
}

function filterBookings() {
    // Implementation for filtering bookings
    const status = document.getElementById('statusFilter').value;
    console.log('Filtering by status:', status);
    // In a real implementation, you would filter the displayed bookings
}

function sortBookings() {
    // Implementation for sorting bookings
    const sort = document.getElementById('dateFilter').value;
    console.log('Sorting by:', sort);
    // In a real implementation, you would re-sort the displayed bookings
}

// Action functions
function viewTicket(bookingId) {
    localStorage.setItem('currentTicket', bookingId);
    window.location.href = 'ticket.html';
}

function downloadReceipt(bookingId) {
    alert('Receipt download functionality would be implemented here.\nIn a production environment, this would generate a PDF receipt.');
}

function cancelBooking(bookingId) {
    if (confirm('Are you sure you want to cancel this booking?')) {
        // In a real implementation, you would update the booking status
        const bookings = getBookings();
        const bookingIndex = bookings.findIndex(b => b.id === bookingId);
        if (bookingIndex !== -1) {
            bookings[bookingIndex].status = 'cancelled';
            saveBookings(bookings);
            alert('Booking cancelled successfully!');
            loadBookingHistory(); // Refresh the display
        }
    }
}

function writeReview(movieId) {
    const review = prompt('Please share your review for this movie:');
    if (review) {
        alert('Thank you for your review!');
        // In a real implementation, you would save the review
    }
}

function showAdminLogin() {
    const password = prompt('Enter admin password:');
    if (password === 'admin123') {
        loginAdmin();
        alert('Admin login successful!');
        window.location.href = 'admin/index.html';
    } else if (password) {
        alert('Incorrect password!');
    }
}