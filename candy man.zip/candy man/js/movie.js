// Movie Details Page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    loadMovieDetails();
    setupEventListeners();
});

function loadMovieDetails() {
    const urlParams = new URLSearchParams(window.location.search);
    const movieId = urlParams.get('id');
    
    if (!movieId) {
        alert('No movie selected');
        window.location.href = 'index.html';
        return;
    }
    
    const movie = getMovieById(movieId);
    if (!movie) {
        alert('Movie not found');
        window.location.href = 'index.html';
        return;
    }
    
    displayMovieDetails(movie);
}

function displayMovieDetails(movie) {
    // Set header background
    document.getElementById('movieHeader').style.backgroundImage = `url('${movie.backdrop}')`;
    
    // Set movie poster
    document.getElementById('moviePoster').src = movie.poster;
    document.getElementById('moviePoster').alt = movie.title;
    
    // Set movie information
    document.getElementById('movieTitle').textContent = movie.title;
    document.getElementById('movieGenre').textContent = movie.genre;
    document.getElementById('movieDuration').textContent = movie.duration;
    document.getElementById('movieRating').textContent = movie.rating;
    document.getElementById('movieDescription').textContent = movie.description;
    document.getElementById('movieCast').textContent = movie.cast.join(', ');
    document.getElementById('movieDirector').textContent = movie.director;
    document.getElementById('movieReleaseDate').textContent = new Date(movie.releaseDate).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
    document.getElementById('movieGenreFull').textContent = movie.genre;
    
    // Set trailer
    document.getElementById('movieTrailer').src = movie.trailer;
    
    // Set overall rating (demo data)
    document.getElementById('overallRating').textContent = movie.rating.toFixed(1);
    
    // Populate showtimes
    const showtimesGrid = document.getElementById('showtimesGrid');
    showtimesGrid.innerHTML = movie.showtimes.map(time => `
        <button class="showtime-btn" onclick="bookShowtime('${time}')">
            ${time}
        </button>
    `).join('');
}

function setupEventListeners() {
    // Admin login button
    document.getElementById('adminLoginBtn').addEventListener('click', function() {
        if (isAdmin()) {
            window.location.href = 'admin/index.html';
        } else {
            showAdminLogin();
        }
    });
    
    // Book ticket button
    document.getElementById('bookTicketBtn').addEventListener('click', function() {
        const urlParams = new URLSearchParams(window.location.search);
        const movieId = urlParams.get('id');
        window.location.href = `booking.html?movie=${movieId}`;
    });
}

function bookShowtime(showtime) {
    const urlParams = new URLSearchParams(window.location.search);
    const movieId = urlParams.get('id');
    
    // Highlight selected showtime
    document.querySelectorAll('.showtime-btn').forEach(btn => {
        btn.classList.remove('selected');
    });
    event.target.classList.add('selected');
    
    // Store selected showtime
    localStorage.setItem('selectedShowtime', showtime);
    
    // Redirect to booking page
    window.location.href = `booking.html?movie=${movieId}&showtime=${showtime}`;
}

function showAdminLogin() {
    const password = prompt('Enter admin password:');
    if (password === 'admin123') {
        loginAdmin();
        alert('Admin login successful!');
        window.location.href = 'admin/index.html';
    } else if (password) {
        alert('Incorrect password!');
    }
}