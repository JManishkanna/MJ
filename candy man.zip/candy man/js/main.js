// Main JavaScript for CineBook Application

document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    loadFeaturedMovies();
    populateBookingForm();
});

function initializeApp() {
    // Check if admin is logged in
    if (isAdmin()) {
        document.getElementById('adminLoginBtn').textContent = 'Admin Panel';
        document.getElementById('adminLoginBtn').addEventListener('click', () => {
            window.location.href = 'admin/index.html';
        });
    }
}

function setupEventListeners() {
    // Admin login button
    document.getElementById('adminLoginBtn').addEventListener('click', function() {
        if (isAdmin()) {
            window.location.href = 'admin/index.html';
        } else {
            showAdminLogin();
        }
    });

    // Search functionality
    document.getElementById('searchInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            performSearch(this.value);
        }
    });

    // Quick booking form
    document.getElementById('movieSelect').addEventListener('change', function() {
        const selectedMovieId = this.value;
        if (selectedMovieId) {
            populateShowtimes(selectedMovieId);
        }
    });

    document.getElementById('bookNowBtn').addEventListener('click', function() {
        const movieId = document.getElementById('movieSelect').value;
        const theaterId = document.getElementById('theaterSelect').value;
        const showtime = document.getElementById('showtimeSelect').value;
        
        if (movieId && theaterId && showtime) {
            window.location.href = `booking.html?movie=${movieId}&theater=${theaterId}&showtime=${showtime}`;
        } else {
            alert('Please select all options to proceed with booking.');
        }
    });
}

function loadFeaturedMovies() {
    const movies = getMovies();
    const container = document.getElementById('featuredMovies');
    
    if (movies.length === 0) {
        container.innerHTML = '<p class="text-center">No movies available at the moment.</p>';
        return;
    }
    
    container.innerHTML = movies.slice(0, 6).map(movie => `
        <div class="movie-card" onclick="viewMovie(${movie.id})">
            <img src="${movie.poster}" alt="${movie.title}" class="movie-poster">
            <div class="movie-info">
                <h3>${movie.title}</h3>
                <div class="movie-meta">
                    <span>${movie.genre}</span>
                    <span class="rating">
                        <i class="fas fa-star"></i> ${movie.rating}
                    </span>
                </div>
                <div class="movie-meta">
                    <span>${movie.duration}</span>
                    <button class="btn" onclick="event.stopPropagation(); bookMovie(${movie.id})">
                        <i class="fas fa-ticket-alt"></i> Book Now
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

function populateBookingForm() {
    const movies = getMovies();
    const theaters = getTheaters();
    
    const movieSelect = document.getElementById('movieSelect');
    const theaterSelect = document.getElementById('theaterSelect');
    
    // Populate movies
    movieSelect.innerHTML = '<option value="">Choose a movie</option>' + 
        movies.map(movie => `<option value="${movie.id}">${movie.title}</option>`).join('');
    
    // Populate theaters
    theaterSelect.innerHTML = '<option value="">Choose a theater</option>' + 
        theaters.map(theater => `<option value="${theater.id}">${theater.name}</option>`).join('');
}

function populateShowtimes(movieId) {
    const movies = getMovies();
    const movie = movies.find(m => m.id == movieId);
    
    if (movie) {
        const showtimeSelect = document.getElementById('showtimeSelect');
        showtimeSelect.innerHTML = '<option value="">Select time</option>' + 
            movie.showtimes.map(time => `<option value="${time}">${time}</option>`).join('');
    }
}

function performSearch(query) {
    if (!query.trim()) return;
    
    const movies = getMovies();
    const theaters = getTheaters();
    
    const results = [...movies, ...theaters].filter(item => 
        item.title?.toLowerCase().includes(query.toLowerCase()) || 
        item.name?.toLowerCase().includes(query.toLowerCase()) ||
        item.description?.toLowerCase().includes(query.toLowerCase())
    );
    
    if (results.length > 0) {
        // Redirect to search results page or show modal
        alert(`Found ${results.length} results for "${query}"`);
        // In a real app, you'd navigate to a search results page
    } else {
        alert('No results found for your search.');
    }
}

function viewMovie(movieId) {
    window.location.href = `movie.html?id=${movieId}`;
}

function bookMovie(movieId) {
    window.location.href = `booking.html?movie=${movieId}`;
}

function showAdminLogin() {
    const password = prompt('Enter admin password:');
    if (password === 'admin123') { // Simple password for demo
        loginAdmin();
        alert('Admin login successful!');
        window.location.href = 'admin/index.html';
    } else if (password) {
        alert('Incorrect password!');
    }
}

// Utility functions
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function formatCurrency(amount) {
    return `₹${amount}`;
}

function getMovieById(id) {
    const movies = getMovies();
    return movies.find(movie => movie.id == id);
}

function getTheaterById(id) {
    const theaters = getTheaters();
    return theaters.find(theater => theater.id == id);
}

// Seat selection helper functions
function generateSeatLayout(rows = 8, cols = 10) {
    const seats = [];
    for (let row = 0; row < rows; row++) {
        const rowSeats = [];
        for (let col = 0; col < cols; col++) {
            const seatId = String.fromCharCode(65 + row) + (col + 1);
            rowSeats.push({
                id: seatId,
                row: String.fromCharCode(65 + row),
                number: col + 1,
                status: 'available', // available, selected, booked
                price: row < 3 ? 150 : 200 // Premium pricing for front rows
            });
        }
        seats.push(rowSeats);
    }
    return seats;
}

function getSeatPrice(row, seatNumber) {
    // Special pricing logic
    if (row === 'A') {
        // Row A: A1-A6 regular (₹299), A7-A10 premium (₹399)
        return seatNumber >= 7 ? 399 : 299;
    } else if (['B', 'C', 'D'].includes(row)) {
        // Rows B, C, D: B1-B6, C1-C6, D1-D6 regular (₹299), B7-B10, C7-C10, D7-D10 premium (₹399)
        return seatNumber >= 7 ? 399 : 299;
    } else {
        // Rows E, F, G, H: E1-E6, F1-F6, G1-G6, H1-H6 regular (₹299), E7-E10, F7-F10, G7-G10, H7-H10 premium (₹399)
        return seatNumber >= 7 ? 399 : 299;
    }
}