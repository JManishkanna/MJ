// Ticket Page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    loadTicket();
    setupEventListeners();
});

function loadTicket() {
    const bookingId = localStorage.getItem('currentTicket');
    if (!bookingId) {
        alert('No ticket found');
        window.location.href = 'history.html';
        return;
    }
    
    const bookings = getBookings();
    const booking = bookings.find(b => b.id === bookingId);
    
    if (!booking) {
        alert('Ticket not found');
        window.location.href = 'history.html';
        return;
    }
    
    displayTicket(booking);
    displayBookingDetails(booking);
}

function displayTicket(booking) {
    const movie = getMovieById(booking.movieId);
    const theater = getTheaterById(booking.theaterId);
    
    // Set ticket background (blended movie and theater image)
    const backgroundElement = document.getElementById('ticketBackground');
    if (movie && theater) {
        // Create a blended background using CSS gradient
        backgroundElement.style.background = `
            linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.3)),
            url('${movie.backdrop}'), 
            url('${theater.image}')
        `;
        backgroundElement.style.backgroundSize = 'cover, 60% 100%, 40% 100%';
        backgroundElement.style.backgroundPosition = 'center, left, right';
        backgroundElement.style.backgroundRepeat = 'no-repeat, no-repeat, no-repeat';
    } else if (movie) {
        backgroundElement.style.backgroundImage = `url('${movie.backdrop}')`;
        backgroundElement.style.backgroundSize = 'cover';
        backgroundElement.style.backgroundPosition = 'center';
    }
    
    // Set ticket content
    document.getElementById('bookingId').textContent = booking.id;
    document.getElementById('ticketQR').src = booking.qrCode || generateQRCode(booking.id);
    document.getElementById('ticketMoviePoster').src = movie ? movie.poster : '';
    document.getElementById('ticketMovieTitle').textContent = booking.movieTitle;
    document.getElementById('ticketTheater').textContent = booking.theaterName;
    document.getElementById('ticketShowtime').textContent = booking.showtime;
    document.getElementById('ticketDate').textContent = new Date().toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
    document.getElementById('ticketSeats').textContent = booking.seats.map(s => s.id).join(', ');
    document.getElementById('ticketTotal').textContent = `₹${booking.totalAmount}`;
}

function displayBookingDetails(booking) {
    const container = document.getElementById('bookingDetails');
    
    container.innerHTML = `
        <div class="detail-card">
            <h4><i class="fas fa-film"></i> Movie Details</h4>
            <p><span class="label">Title:</span> <span>${booking.movieTitle}</span></p>
            <p><span class="label">Duration:</span> <span>${getMovieDuration(booking.movieId)}</span></p>
            <p><span class="label">Rating:</span> <span>${getMovieRating(booking.movieId)}</span></p>
        </div>
        
        <div class="detail-card">
            <h4><i class="fas fa-landmark"></i> Theater Information</h4>
            <p><span class="label">Name:</span> <span>${booking.theaterName}</span></p>
            <p><span class="label">Location:</span> <span>${getTheaterLocation(booking.theaterId)}</span></p>
            <p><span class="label">Facilities:</span> <span>${getTheaterFacilities(booking.theaterId)}</span></p>
        </div>
        
        <div class="detail-card">
            <h4><i class="fas fa-couch"></i> Seating Information</h4>
            <p><span class="label">Seats:</span> <span>${booking.seats.map(s => s.id).join(', ')}</span></p>
            <p><span class="label">Seat Count:</span> <span>${booking.seats.length}</span></p>
            <p><span class="label">Seating Area:</span> <span>${getSeatingArea(booking.seats)}</span></p>
        </div>
        
        ${booking.snacks && booking.snacks.length > 0 ? `
        <div class="detail-card">
            <h4><i class="fas fa-popcorn"></i> Snacks Ordered</h4>
            ${booking.snacks.map(snack => `
                <p><span class="label">${snack.name}:</span> <span>${snack.quantity} × ₹${snack.price} = ₹${snack.quantity * snack.price}</span></p>
            `).join('')}
            <p><span class="label">Total Snacks:</span> <span>₹${booking.snacks.reduce((sum, snack) => sum + (snack.price * snack.quantity), 0)}</span></p>
        </div>
        ` : ''}
        
        <div class="detail-card">
            <h4><i class="fas fa-receipt"></i> Payment Information</h4>
            <p><span class="label">Ticket Price:</span> <span>₹${booking.seats.reduce((sum, seat) => sum + seat.price, 0)}</span></p>
            ${booking.snacks && booking.snacks.length > 0 ? `
            <p><span class="label">Snacks:</span> <span>₹${booking.snacks.reduce((sum, snack) => sum + (snack.price * snack.quantity), 0)}</span></p>
            ` : ''}
            <p><span class="label">Total Amount:</span> <span class="total-amount">₹${booking.totalAmount}</span></p>
            <p><span class="label">Payment Status:</span> <span class="paid">PAID</span></p>
        </div>
        
        <div class="detail-card">
            <h4><i class="fas fa-info-circle"></i> Important Information</h4>
            <p><span class="label">Booking ID:</span> <span>${booking.id}</span></p>
            <p><span class="label">Booking Date:</span> <span>${new Date(booking.date).toLocaleString()}</span></p>
            <p><span class="label">Status:</span> <span class="confirmed">CONFIRMED</span></p>
            <p><span class="label">Valid Until:</span> <span>${getValidUntil(booking.showtime)}</span></p>
        </div>
    `;
}

function setupEventListeners() {
    // Admin login button
    document.getElementById('adminLoginBtn').addEventListener('click', function() {
        if (isAdmin()) {
            window.location.href = 'admin/index.html';
        } else {
            showAdminLogin();
        }
    });
}

// Helper functions
function getMovieDuration(movieId) {
    const movie = getMovieById(movieId);
    return movie ? movie.duration : 'N/A';
}

function getMovieRating(movieId) {
    const movie = getMovieById(movieId);
    return movie ? `${movie.rating}/10` : 'N/A';
}

function getTheaterLocation(theaterId) {
    const theater = getTheaterById(theaterId);
    return theater ? theater.location : 'N/A';
}

function getTheaterFacilities(theaterId) {
    const theater = getTheaterById(theaterId);
    return theater ? theater.facilities.join(', ') : 'N/A';
}

function getSeatingArea(seats) {
    if (seats.length === 0) return 'N/A';
    
    const rows = [...new Set(seats.map(s => s.id.charAt(0)))];
    if (rows.length === 1) {
        const row = rows[0];
        return row < 'D' ? 'Front Section (Premium)' : 
               row < 'G' ? 'Middle Section' : 'Back Section';
    }
    return 'Multiple Sections';
}

function getValidUntil(showtime) {
    const showDate = new Date();
    const [time, period] = showtime.split(' ');
    const [hours, minutes] = time.split(':').map(Number);
    
    let showHours = hours;
    if (period === 'PM' && hours !== 12) showHours += 12;
    if (period === 'AM' && hours === 12) showHours = 0;
    
    showDate.setHours(showHours, minutes, 0, 0);
    
    // Valid until 30 minutes before showtime
    showDate.setMinutes(showDate.getMinutes() - 30);
    
    return showDate.toLocaleString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Ticket actions
function printTicket() {
    window.print();
}

function downloadTicket() {
    // In a real application, this would generate a PDF
    alert('PDF download functionality would be implemented here.\nIn a production environment, this would generate a printable PDF ticket.');
}

function shareTicket() {
    if (navigator.share) {
        navigator.share({
            title: 'My Movie Ticket',
            text: 'Check out my movie ticket!',
            url: window.location.href
        }).catch(console.error);
    } else {
        // Fallback for browsers that don't support Web Share API
        const bookingId = localStorage.getItem('currentTicket');
        const shareText = `Check out my movie ticket! Booking ID: ${bookingId}`;
        const tempInput = document.createElement('input');
        tempInput.value = shareText;
        document.body.appendChild(tempInput);
        tempInput.select();
        document.execCommand('copy');
        document.body.removeChild(tempInput);
        alert('Ticket information copied to clipboard!');
    }
}

function showAdminLogin() {
    const password = prompt('Enter admin password:');
    if (password === 'admin123') {
        loginAdmin();
        alert('Admin login successful!');
        window.location.href = 'admin/index.html';
    } else if (password) {
        alert('Incorrect password!');
    }
}