// Movies Page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    loadMovies();
    setupEventListeners();
});

function loadMovies() {
    const movies = getMovies();
    displayMovies(movies);
}

function displayMovies(movies) {
    const container = document.getElementById('moviesGrid');
    
    if (movies.length === 0) {
        container.innerHTML = `
            <div class="empty-state" style="grid-column: 1 / -1; text-align: center; padding: 3rem;">
                <i class="fas fa-film" style="font-size: 3rem; color: #ccc; margin-bottom: 1rem;"></i>
                <h3>No Movies Found</h3>
                <p>Try adjusting your filters or check back later</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = movies.map(movie => `
        <div class="movie-card-large" onclick="viewMovie(${movie.id})">
            <img src="${movie.poster}" alt="${movie.title}" class="movie-poster-large">
            <div class="movie-info-large">
                <h3>${movie.title}</h3>
                <div class="movie-meta-large">
                    <span><i class="fas fa-tags"></i> ${movie.genre}</span>
                    <span><i class="fas fa-clock"></i> ${movie.duration}</span>
                    <span class="rating-large">
                        <i class="fas fa-star"></i> ${movie.rating}
                    </span>
                    <span><i class="fas fa-rupee-sign"></i> ₹${movie.price}</span>
                </div>
                <p class="movie-description-short">${movie.description.substring(0, 120)}...</p>
                <div class="movie-actions">
                    <button class="btn btn-primary" onclick="event.stopPropagation(); bookMovie(${movie.id})">
                        <i class="fas fa-ticket-alt"></i> Book Now
                    </button>
                    <button class="btn" onclick="event.stopPropagation(); viewMovieDetails(${movie.id})">
                        <i class="fas fa-info-circle"></i> Details
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

function setupEventListeners() {
    // Admin login button
    document.getElementById('adminLoginBtn').addEventListener('click', function() {
        if (isAdmin()) {
            window.location.href = 'admin/index.html';
        } else {
            showAdminLogin();
        }
    });
    
    // Filter event listeners
    document.getElementById('genreFilter').addEventListener('change', filterAndSortMovies);
    document.getElementById('ratingFilter').addEventListener('change', filterAndSortMovies);
    document.getElementById('sortFilter').addEventListener('change', filterAndSortMovies);
}

function filterAndSortMovies() {
    const genreFilter = document.getElementById('genreFilter').value;
    const ratingFilter = parseFloat(document.getElementById('ratingFilter').value);
    const sortFilter = document.getElementById('sortFilter').value;
    
    let movies = getMovies();
    
    // Apply genre filter
    if (genreFilter !== 'all') {
        movies = movies.filter(movie => movie.genre.includes(genreFilter));
    }
    
    // Apply rating filter
    if (ratingFilter > 0) {
        movies = movies.filter(movie => movie.rating >= ratingFilter);
    }
    
    // Apply sorting
    switch (sortFilter) {
        case 'title':
            movies.sort((a, b) => a.title.localeCompare(b.title));
            break;
        case 'rating':
            movies.sort((a, b) => b.rating - a.rating);
            break;
        case 'price':
            movies.sort((a, b) => a.price - b.price);
            break;
        case 'date':
            movies.sort((a, b) => new Date(b.releaseDate) - new Date(a.releaseDate));
            break;
    }
    
    displayMovies(movies);
}

// Action functions
function viewMovie(movieId) {
    window.location.href = `movie.html?id=${movieId}`;
}

function bookMovie(movieId) {
    window.location.href = `booking.html?movie=${movieId}`;
}

function viewMovieDetails(movieId) {
    window.location.href = `movie.html?id=${movieId}`;
}

function showAdminLogin() {
    const password = prompt('Enter admin password:');
    if (password === 'admin123') {
        loginAdmin();
        alert('Admin login successful!');
        window.location.href = 'admin/index.html';
    } else if (password) {
        alert('Incorrect password!');
    }
}