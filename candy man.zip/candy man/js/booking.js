// Booking Page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    loadBookingPage();
    generateSeatLayout();
    setupEventListeners();
    loadSnacks();
});

let selectedSeats = [];
let selectedSnacks = [];
let currentMovie = null;
let currentTheater = null;
let currentShowtime = null;

function loadBookingPage() {
    const urlParams = new URLSearchParams(window.location.search);
    const movieId = urlParams.get('movie');
    const theaterId = urlParams.get('theater') || '1'; // Default theater
    const showtime = urlParams.get('showtime') || localStorage.getItem('selectedShowtime') || '7:00 PM';
    
    if (!movieId) {
        alert('No movie selected');
        window.location.href = 'index.html';
        return;
    }
    
    currentMovie = getMovieById(movieId);
    currentTheater = getTheaterById(theaterId);
    currentShowtime = showtime;
    
    if (!currentMovie) {
        alert('Movie not found');
        window.location.href = 'index.html';
        return;
    }
    
    displayBookingInfo();
}

function displayBookingInfo() {
    // Set movie information
    document.getElementById('bookingMoviePoster').src = currentMovie.poster;
    document.getElementById('bookingMovieTitle').textContent = currentMovie.title;
    document.getElementById('bookingTheater').textContent = currentTheater ? currentTheater.name : 'Cineplex Grand';
    document.getElementById('bookingShowtime').textContent = `Showtime: ${currentShowtime}`;
    document.getElementById('bookingDate').textContent = `Date: ${new Date().toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    })}`;
}

function generateSeatLayout() {
    const container = document.getElementById('seatsContainer');
    const seats = generateSeatLayoutData();
    
    console.log('Generated seats data:', seats);
    
    container.innerHTML = seats.map((row, rowIndex) => {
        const rowLabel = String.fromCharCode(65 + rowIndex);
        return `
            <div class="seat-row">
                <div class="row-label">${rowLabel}</div>
                ${row.map(seat => {
                    // Determine seat class based on premium status
                    const seatClass = seat.isPremium ? 'vip' : 'available';
                    console.log(`Rendering seat ${seat.id}: class=${seatClass}, price=${seat.price}`);
                    return `
                    <div class="seat-container">
                        <div class="seat ${seatClass}" 
                             data-seat="${seat.id}" 
                             data-price="${seat.price}"
                             onclick="toggleSeat('${seat.id}', ${seat.price})">
                        </div>
                        <div class="seat-number">${seat.id}</div>
                    </div>
                `;}).join('')}
            </div>
        `;
    }).join('');
    
    // Add column labels
    const colLabels = '<div class="col-labels">' + 
        '<div></div>' + // Empty space for row labels
        Array.from({length: 10}, (_, i) => `<div class="col-label">${i + 1}</div>`).join('') + 
        '</div>';
    
    container.insertAdjacentHTML('afterbegin', colLabels);
    
    console.log('Seat layout generated');
}

function generateSeatLayoutData() {
    const seats = [];
    for (let row = 0; row < 8; row++) {
        const rowSeats = [];
        for (let col = 0; col < 10; col++) {
            const seatId = String.fromCharCode(65 + row) + (col + 1);
            const seatNumber = col + 1;
            const rowChar = String.fromCharCode(65 + row);
            
            // Special pricing logic
            let price;
            if (rowChar === 'A') {
                // Row A: A1-A6 regular (₹299), A7-A10 premium (₹399)
                price = seatNumber >= 7 ? 399 : 299;
            } else if (['B', 'C', 'D'].includes(rowChar)) {
                // Rows B, C, D: B1-B6, C1-C6, D1-D6 regular (₹299), B7-B10, C7-C10, D7-D10 premium (₹399)
                price = seatNumber >= 7 ? 399 : 299;
            } else {
                // Rows E, F, G, H: E1-E6, F1-F6, G1-G6, H1-H6 regular (₹299), E7-E10, F7-F10, G7-G10, H7-H10 premium (₹399)
                price = seatNumber >= 7 ? 399 : 299;
            }
            
            // Determine if this is a premium seat based on pricing
            const isPremium = price === 399;
            
            // Define popular seats (these are seats that are typically in high demand)
            const isPopular = (rowChar === 'C' && seatNumber >= 4 && seatNumber <= 7) || 
                              (rowChar === 'D' && seatNumber >= 3 && seatNumber <= 8) ||
                              (rowChar === 'E' && seatNumber >= 3 && seatNumber <= 8);
            
            // Debug logging
            console.log(`Seat ${seatId}: price=${price}, isPremium=${isPremium}, isPopular=${isPopular}`);
            
            rowSeats.push({
                id: seatId,
                status: 'available', // available, selected, booked
                price: price,
                isPremium: isPremium,
                isPopular: isPopular
            });
        }
        seats.push(rowSeats);
    }
    return seats;
}

function toggleSeat(seatId, price) {
    const seatElement = document.querySelector(`[data-seat="${seatId}"]`);
    
    if (seatElement.classList.contains('booked')) {
        return; // Can't select booked seats
    }
    
    if (seatElement.classList.contains('selected')) {
        // Deselect seat
        seatElement.classList.remove('selected');
        selectedSeats = selectedSeats.filter(seat => seat.id !== seatId);
    } else {
        // Select seat (max 8 seats)
        if (selectedSeats.length >= 8) {
            alert('You can select maximum 8 seats');
            return;
        }
        seatElement.classList.add('selected');
        selectedSeats.push({
            id: seatId,
            price: price
        });
    }
    
    updateSelectedSeatsDisplay();
    updatePriceSummary();
    updateProceedButton();
}

function updateSelectedSeatsDisplay() {
    const container = document.getElementById('selectedSeatsList');
    
    if (selectedSeats.length === 0) {
        container.innerHTML = '<p>No seats selected yet</p>';
        return;
    }
    
    container.innerHTML = `
        <div class="selected-seats-list">
            ${selectedSeats.map(seat => `
                <div class="selected-seat-tag">
                    <span>${seat.id}</span>
                    <span>(₹${seat.price})</span>
                    <button class="remove-seat" onclick="removeSeat('${seat.id}')">×</button>
                </div>
            `).join('')}
        </div>
    `;
}

function removeSeat(seatId) {
    selectedSeats = selectedSeats.filter(seat => seat.id !== seatId);
    const seatElement = document.querySelector(`[data-seat="${seatId}"]`);
    seatElement.classList.remove('selected');
    updateSelectedSeatsDisplay();
    updatePriceSummary();
    updateProceedButton();
}

function updatePriceSummary() {
    const ticketCount = selectedSeats.length;
    const ticketPrice = selectedSeats.reduce((sum, seat) => sum + seat.price, 0);
    const snackPrice = selectedSnacks.reduce((sum, snack) => sum + (snack.price * snack.quantity), 0);
    const totalPrice = ticketPrice + snackPrice;
    
    document.getElementById('ticketCount').textContent = ticketCount;
    document.getElementById('ticketPrice').textContent = `₹${ticketPrice}`;
    document.getElementById('snackCount').textContent = selectedSnacks.reduce((sum, snack) => sum + snack.quantity, 0);
    document.getElementById('snackPrice').textContent = `₹${snackPrice}`;
    document.getElementById('totalPrice').textContent = `₹${totalPrice}`;
}

function updateProceedButton() {
    const button = document.getElementById('proceedToPayment');
    if (selectedSeats.length > 0) {
        button.disabled = false;
        button.style.opacity = '1';
    } else {
        button.disabled = true;
        button.style.opacity = '0.5';
    }
}

function loadSnacks() {
    const snacks = getSnacks();
    const container = document.getElementById('snacksGrid');
    
    container.innerHTML = snacks.map(snack => `
        <div class="snack-item">
            <img src="${snack.image}" alt="${snack.name}" class="snack-image">
            <div class="snack-info">
                <h4>${snack.name}</h4>
                <div class="snack-price">₹${snack.price}</div>
                <div class="snack-quantity">
                    <button class="quantity-btn minus" onclick="updateSnackQuantity(${snack.id}, -1)">-</button>
                    <span class="quantity-display" id="snack-${snack.id}">0</span>
                    <button class="quantity-btn plus" onclick="updateSnackQuantity(${snack.id}, 1)">+</button>
                </div>
                <div class="snack-added" id="added-${snack.id}">Added to order</div>
            </div>
        </div>
    `).join('');
}

function updateSnackQuantity(snackId, change) {
    let snack = selectedSnacks.find(s => s.id == snackId);
    const allSnacks = getSnacks();
    const snackData = allSnacks.find(s => s.id == snackId);
    
    if (!snackData) return;
    
    if (!snack) {
        snack = {
            id: snackId,
            name: snackData.name,
            price: snackData.price,
            quantity: 0
        };
        selectedSnacks.push(snack);
    }
    
    const newQuantity = snack.quantity + change;
    
    if (newQuantity < 0) return;
    if (newQuantity > 10) {
        alert('Maximum 10 items per snack type');
        return;
    }
    
    snack.quantity = newQuantity;
    
    // Update display
    document.getElementById(`snack-${snackId}`).textContent = newQuantity;
    
    // Show/hide added indicator
    const addedIndicator = document.getElementById(`added-${snackId}`);
    if (newQuantity > 0) {
        addedIndicator.style.display = 'block';
    } else {
        addedIndicator.style.display = 'none';
        // Remove from selected snacks if quantity is 0
        selectedSnacks = selectedSnacks.filter(s => s.id != snackId || s.quantity > 0);
    }
    
    updatePriceSummary();
}

function setupEventListeners() {
    // Admin login button
    document.getElementById('adminLoginBtn').addEventListener('click', function() {
        if (isAdmin()) {
            window.location.href = 'admin/index.html';
        } else {
            showAdminLogin();
        }
    });
    
    // Proceed to payment button
    document.getElementById('proceedToPayment').addEventListener('click', function() {
        if (selectedSeats.length === 0) {
            alert('Please select at least one seat');
            return;
        }
        
        processBooking();
    });
    
    // Smart select button
    document.getElementById('smartSelectBtn').addEventListener('click', function() {
        smartSelectSeats();
    });
    
    // Find best seats button
    document.getElementById('findBestSeatsBtn').addEventListener('click', function() {
        findBestSeats();
    });
    
    // Update selected seats panel when seats are selected
    updateSelectedSeatsPanel();
    updatePricePanel();
}

function processBooking() {
    // Create booking data
    const bookingData = {
        movieId: currentMovie.id,
        movieTitle: currentMovie.title,
        theaterId: currentTheater ? currentTheater.id : 1,
        theaterName: currentTheater ? currentTheater.name : 'Cineplex Grand',
        showtime: currentShowtime,
        seats: selectedSeats,
        snacks: selectedSnacks,
        totalAmount: selectedSeats.reduce((sum, seat) => sum + seat.price, 0) + 
                    selectedSnacks.reduce((sum, snack) => sum + (snack.price * snack.quantity), 0),
        qrCode: generateQRCode(Date.now().toString())
    };
    
    // Save booking
    const booking = createBooking(bookingData);
    
    // Show confirmation
    showBookingConfirmation(booking);
}

function showBookingConfirmation(booking) {
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.id = 'confirmationModal';
    modal.innerHTML = `
        <div class="modal-content">
            <button class="close-modal" onclick="closeModal()">&times;</button>
            <div class="modal-header">
                <h2><i class="fas fa-check-circle" style="color: #28a745;"></i> Booking Confirmed!</h2>
                <p>Your movie tickets have been successfully booked</p>
            </div>
            
            <div class="ticket-qr">
                <img src="${booking.qrCode}" alt="QR Code">
                <p>Booking ID: ${booking.id}</p>
            </div>
            
            <div class="ticket-details">
                <h3>Booking Details</h3>
                <p><strong>Movie:</strong> <span>${booking.movieTitle}</span></p>
                <p><strong>Theater:</strong> <span>${booking.theaterName}</span></p>
                <p><strong>Showtime:</strong> <span>${booking.showtime}</span></p>
                <p><strong>Date:</strong> <span>${new Date().toLocaleDateString()}</span></p>
                <p><strong>Seats:</strong> <span>${booking.seats.map(s => s.id).join(', ')}</span></p>
                ${booking.snacks.length > 0 ? 
                    `<p><strong>Snacks:</strong> <span>${booking.snacks.map(s => `${s.name} (${s.quantity})`).join(', ')}</span></p>` : ''}
                <p><strong>Total:</strong> <span>₹${booking.totalAmount}</span></p>
            </div>
            
            <button class="btn btn-primary" onclick="viewTicket('${booking.id}')">
                <i class="fas fa-ticket-alt"></i> View Ticket
            </button>
            <button class="btn" onclick="goToHome()" style="margin-left: 10px;">
                <i class="fas fa-home"></i> Back to Home
            </button>
        </div>
    `;
    
    document.body.appendChild(modal);
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function closeModal() {
    const modal = document.getElementById('confirmationModal');
    if (modal) {
        modal.remove();
        document.body.style.overflow = 'auto';
    }
}

function viewTicket(bookingId) {
    localStorage.setItem('currentTicket', bookingId);
    window.location.href = 'ticket.html';
}

function findBestSeats() {
    // Clear any previously selected seats
    selectedSeats = [];
    document.querySelectorAll('.seat.selected').forEach(seat => {
        seat.classList.remove('selected');
    });
    
    // Get number of people from input
    const numPeopleInput = document.getElementById('numPeople').value;
    const numPeople = parseInt(numPeopleInput);
    
    if (isNaN(numPeople) || numPeople < 1 || numPeople > 8) {
        alert('Please enter a valid number between 1 and 8');
        return;
    }
    
    // Get all available seats
    const availableSeats = [];
    document.querySelectorAll('.seat.available, .seat.vip').forEach(seatElement => {
        const seatId = seatElement.getAttribute('data-seat');
        const price = parseFloat(seatElement.getAttribute('data-price'));
        const row = seatId.charAt(0);
        const number = parseInt(seatId.substring(1));
        
        availableSeats.push({
            id: seatId,
            element: seatElement,
            row: row,
            number: number,
            price: price
        });
    });
    
    if (availableSeats.length === 0) {
        alert('No available seats found!');
        return;
    }
    
    if (numPeople > availableSeats.length) {
        alert(`Only ${availableSeats.length} seats available. Please select ${availableSeats.length} or fewer.`);
        return;
    }
    
    // Sort available seats by row and seat number (try to get adjacent seats in middle rows)
    availableSeats.sort((a, b) => {
        // Prefer middle rows (C, D, E, F) over front/back rows
        const rowPriority = {'C': 1, 'D': 1, 'E': 1, 'F': 1, 'B': 2, 'G': 2, 'A': 3, 'H': 3};
        if (rowPriority[a.row] !== rowPriority[b.row]) {
            return rowPriority[a.row] - rowPriority[b.row];
        }
        // Within same row, prefer middle seats (4-7)
        const seatPosition = Math.abs(a.number - 5.5); // 5.5 is middle of 10 seats
        const bSeatPosition = Math.abs(b.number - 5.5);
        return seatPosition - bSeatPosition;
    });
    
    // Try to find adjacent seats in the same row
    let foundSeats = [];
    
    // Look for adjacent seats in each row
    for (const row of ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']) {
        const rowSeats = availableSeats.filter(seat => seat.row === row);
        if (rowSeats.length >= numPeople) {
            // Check for adjacent seats in this row
            for (let i = 0; i <= rowSeats.length - numPeople; i++) {
                let isAdjacent = true;
                for (let j = 1; j < numPeople; j++) {
                    if (rowSeats[i + j].number !== rowSeats[i + j - 1].number + 1) {
                        isAdjacent = false;
                        break;
                    }
                }
                if (isAdjacent) {
                    foundSeats = rowSeats.slice(i, i + numPeople);
                    break;
                }
            }
            if (foundSeats.length > 0) break; // Found adjacent seats in this row
        }
    }
    
    // If no adjacent seats found, just pick the best available seats
    if (foundSeats.length === 0) {
        foundSeats = availableSeats.slice(0, numPeople);
    }
    
    // Select the found seats
    const selectedSeatsArray = [];
    foundSeats.forEach(seat => {
        seat.element.classList.add('selected');
        selectedSeatsArray.push({
            id: seat.id,
            price: seat.price
        });
    });
    
    selectedSeats = selectedSeatsArray;
    
    // Update UI
    updateSelectedSeatsDisplay();
    updateSelectedSeatsPanel();
    updatePriceSummary();
    updatePricePanel();
    updateProceedButton();
    
    // Show confirmation
    const seatIds = selectedSeats.map(s => s.id).join(', ');
    const totalPrice = selectedSeats.reduce((sum, seat) => sum + seat.price, 0);
    alert(`Best seats found!

Selected seats: ${seatIds}
Total price: ₹${totalPrice}

These seats offer the best viewing experience.`);
}

function updateSelectedSeatsPanel() {
    const container = document.getElementById('selectedSeatsListPanel');
    
    if (selectedSeats.length === 0) {
        container.innerHTML = '<p>No seats selected yet</p>';
        return;
    }
    
    container.innerHTML = `
        <div class="selected-seats-list">
            ${selectedSeats.map(seat => `
                <div class="selected-seat-tag">
                    <span>${seat.id}</span>
                </div>
            `).join('')}
        </div>
    `;
}

function updatePricePanel() {
    const ticketPrice = selectedSeats.reduce((sum, seat) => sum + seat.price, 0);
    const convenienceFee = selectedSeats.length * 25; // ₹25 convenience fee per seat
    const totalPrice = ticketPrice + convenienceFee;
    
    document.getElementById('panelTicketPrice').textContent = `₹${ticketPrice}`;
    document.getElementById('convenienceFee').textContent = `₹${convenienceFee}`;
    document.getElementById('panelTotalPrice').textContent = `₹${totalPrice}`;
}

// Update the updateSelectedSeatsDisplay function to also update the panel
const originalUpdateSelectedSeatsDisplay = updateSelectedSeatsDisplay;
updateSelectedSeatsDisplay = function() {
    originalUpdateSelectedSeatsDisplay();
    updateSelectedSeatsPanel();
    updatePricePanel();
};

function goToHome() {
    closeModal();
    window.location.href = 'index.html';
}

function smartSelectSeats() {
    // Clear any previously selected seats
    selectedSeats = [];
    document.querySelectorAll('.seat.selected').forEach(seat => {
        seat.classList.remove('selected');
    });
    
    // Get all available seats (both regular and premium)
    const availableSeats = [];
    document.querySelectorAll('.seat.available, .seat.vip').forEach(seatElement => {
        const seatId = seatElement.getAttribute('data-seat');
        const price = parseFloat(seatElement.getAttribute('data-price'));
        const row = seatId.charAt(0);
        const number = parseInt(seatId.substring(1));
        
        availableSeats.push({
            id: seatId,
            element: seatElement,
            row: row,
            number: number,
            price: price,
            // Score based on ideal seat position (middle rows, center seats)
            score: calculateSeatScore(row, number, price)
        });
    });
    
    if (availableSeats.length === 0) {
        alert('No available seats found!');
        return;
    }
    
    // Ask user how many seats they want
    const seatCount = prompt('How many seats would you like to select? (1-8)');
    const count = parseInt(seatCount);
    
    if (isNaN(count) || count < 1 || count > 8) {
        alert('Please enter a valid number between 1 and 8');
        return;
    }
    
    if (count > availableSeats.length) {
        alert(`Only ${availableSeats.length} seats available. Please select ${availableSeats.length} or fewer.`);
        return;
    }
    
    // Sort seats by score (best first)
    availableSeats.sort((a, b) => b.score - a.score);
    
    // Select the best seats
    const selectedSeatsArray = [];
    for (let i = 0; i < count; i++) {
        const seat = availableSeats[i];
        seat.element.classList.add('selected');
        selectedSeatsArray.push({
            id: seat.id,
            price: seat.price
        });
    }
    
    selectedSeats = selectedSeatsArray;
    
    // Update UI
    updateSelectedSeatsDisplay();
    updatePriceSummary();
    updateProceedButton();
    
    // Show confirmation
    const seatIds = selectedSeats.map(s => s.id).join(', ');
    const totalPrice = selectedSeats.reduce((sum, seat) => sum + seat.price, 0);
    alert(`Smart selection completed!

Selected seats: ${seatIds}
Total price: ₹${totalPrice}

These seats were chosen based on optimal viewing position.`);
}

function calculateSeatScore(row, number, price) {
    // Convert row letter to number (A=0, B=1, etc.)
    const rowIndex = row.toUpperCase().charCodeAt(0) - 65;
    
    // Theater has 8 rows and 10 seats per row
    const totalRows = 8;
    const totalSeats = 10;
    
    // Score components:
    
    // 1. Row position score (middle rows are better)
    // Rows 3-5 (D, E, F) are ideal - score them highest
    let rowScore = 0;
    if (rowIndex >= 3 && rowIndex <= 5) {
        rowScore = 100; // Perfect row position
    } else if (rowIndex >= 2 || rowIndex <= 6) {
        rowScore = 80;  // Good row position
    } else {
        rowScore = 60;  // Acceptable row position
    }
    
    // 2. Center position score (middle seats are better)
    // Seats 4, 5, 6, 7 (center area) are ideal
    const centerDistance = Math.abs(number - 5.5); // 5.5 is center of 10 seats
    let centerScore = 100 - (centerDistance * 15); // Lower distance = higher score
    
    // 3. Price factor - updated for new pricing structure
    let priceScore = 100;
    if (row === 'A') {
        // Row A special pricing
        if (number >= 7) {
            // A7-A10 premium seats
            priceScore = 90; // Slight premium but good value
        } else {
            // A1-A6 regular seats
            priceScore = 100; // Best value
        }
    } else if (['B', 'C', 'D'].includes(row)) {
        // Rows B, C, D: seat number based pricing
        if (number >= 7) {
            // B7-B10, C7-C10, D7-D10 premium seats
            priceScore = 90; // Good premium value
        } else {
            // B1-B6, C1-C6, D1-D6 regular seats
            priceScore = 100; // Best value
        }
    } else {
        // Rows E, F, G, H: all regular
        priceScore = 100; // Best value
    }
    
    // 4. Edge avoidance (avoid extreme ends)
    let edgeScore = 100;
    if (number === 1 || number === 10 || number === 2 || number === 9) {
        edgeScore = 70; // Penalty for edge seats
    }
    
    // Combined weighted score
    const totalScore = (rowScore * 0.35) + (centerScore * 0.35) + (priceScore * 0.2) + (edgeScore * 0.1);
    
    return totalScore;
}

function showAdminLogin() {
    const password = prompt('Enter admin password:');
    if (password === 'admin123') {
        loginAdmin();
        alert('Admin login successful!');
        window.location.href = 'admin/index.html';
    } else if (password) {
        alert('Incorrect password!');
    }
}