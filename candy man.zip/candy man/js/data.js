// Sample Data for CineBook Application

// Initialize sample data if not exists
function initializeData() {
    if (!localStorage.getItem('movies')) {
        const movies = [
            {
                id: 1,
                title: "Avatar: The Way of Water",
                genre: "Sci-Fi/Adventure",
                duration: "3h 12m",
                rating: 7.6,
                poster: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
                backdrop: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80",
                description: "Jake Sully lives with his newfound family formed on the extrasolar moon Pandora. Once a familiar threat returns to finish what was previously started, Jake must work with Neytiri and the army of the Na'vi race to protect their home.",
                cast: ["Sam Worthington", "Zoe Saldaña", "Sigourney Weaver", "Stephen Lang"],
                director: "James Cameron",
                releaseDate: "2022-12-16",
                trailer: "https://www.youtube.com/embed/a8Gx8wiNbs8",
                showtimes: ["10:00 AM", "1:30 PM", "5:00 PM", "8:30 PM"],
                price: 299
            },
            {
                id: 2,
                title: "Top Gun: Maverick",
                genre: "Action/Drama",
                duration: "2h 11m",
                rating: 8.3,
                poster: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
                backdrop: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80",
                description: "After thirty years, Maverick is still pushing the envelope as a top naval aviator, but must confront ghosts of his past when he leads TOP GUN's elite graduates on a mission that demands the ultimate sacrifice from those chosen to fly it.",
                cast: ["Tom Cruise", "Miles Teller", "Jennifer Connelly", "Jon Hamm"],
                director: "Joseph Kosinski",
                releaseDate: "2022-05-27",
                trailer: "https://www.youtube.com/embed/giXco2jaZ_4",
                showtimes: ["11:00 AM", "2:15 PM", "6:30 PM", "9:45 PM"],
                price: 279
            },
            {
                id: 3,
                title: "Black Panther: Wakanda Forever",
                genre: "Action/Adventure",
                duration: "2h 41m",
                rating: 6.7,
                poster: "https://images.unsplash.com/photo-1485846234645-a62644f84728?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
                backdrop: "https://images.unsplash.com/photo-1485846234645-a62644f84728?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80",
                description: "The people of Wakanda fight to protect their home from intervening world powers as they mourn the death of King T'Challa.",
                cast: ["Letitia Wright", "Lupita Nyong'o", "Danai Gurira", "Winston Duke"],
                director: "Ryan Coogler",
                releaseDate: "2022-11-11",
                trailer: "https://www.youtube.com/embed/_Z3QKkl1WyM",
                showtimes: ["12:00 PM", "3:30 PM", "7:00 PM", "10:30 PM"],
                price: 329
            }
        ];
        localStorage.setItem('movies', JSON.stringify(movies));
    }

    if (!localStorage.getItem('theaters')) {
        const theaters = [
            {
                id: 1,
                name: "Cineplex Grand",
                location: "Downtown Mall, 123 Main St",
                image: "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
                interior: "https://images.unsplash.com/photo-1533488765986-dfa2a9939ac0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
                facilities: ["IMAX Screen", "4DX", "Dolby Atmos", "VIP Seating"],
                movies: [1, 2, 3]
            },
            {
                id: 2,
                name: "Star Cinema",
                location: "Westfield Plaza, 456 Oak Ave",
                image: "https://images.unsplash.com/photo-1534447677768-be436bb09401?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
                interior: "https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
                facilities: ["Premium Sound", "Comfort Seats", "Concession Stand"],
                movies: [1, 2]
            },
            {
                id: 3,
                name: "Galaxy Theaters",
                location: "Riverside Center, 789 River Rd",
                image: "https://images.unsplash.com/photo-1569411032431-07598b0012c2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
                interior: "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
                facilities: ["Laser Projection", "Reclining Seats", "Private Suites"],
                movies: [2, 3]
            }
        ];
        localStorage.setItem('theaters', JSON.stringify(theaters));
    }

    if (!localStorage.getItem('snacks')) {
        const snacks = [
            {
                id: 1,
                name: "Large Popcorn",
                price: 199,
                image: "https://images.unsplash.com/photo-1543362906-acfc16c67564?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
                category: "Popcorn"
            },
            {
                id: 2,
                name: "Medium Soda",
                price: 129,
                image: "https://images.unsplash.com/photo-1594652397527-9814ac0f56c8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
                category: "Drinks"
            },
            {
                id: 3,
                name: "Candy Combo",
                price: 249,
                image: "https://images.unsplash.com/photo-1582550940043-577737739de0?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
                category: "Candy"
            },
            {
                id: 4,
                name: "Nachos with Cheese",
                price: 229,
                image: "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
                category: "Food"
            },
            {
                id: 5,
                name: "Hot Dog Combo",
                price: 179,
                image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
                category: "Food"
            },
            {
                id: 6,
                name: "Ice Cream Sundae",
                price: 149,
                image: "https://images.unsplash.com/photo-1505394033641-40c6ad1178d7?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
                category: "Desserts"
            }
        ];
        localStorage.setItem('snacks', JSON.stringify(snacks));
    }

    if (!localStorage.getItem('parking')) {
        const parking = {
            car: {
                total: 100,
                available: 85,
                price: 49
            },
            bike: {
                total: 50,
                available: 32,
                price: 19
            }
        };
        localStorage.setItem('parking', JSON.stringify(parking));
    }

    if (!localStorage.getItem('bookings')) {
        localStorage.setItem('bookings', JSON.stringify([]));
    }

    if (!localStorage.getItem('upcomingMovies')) {
        const upcomingMovies = [
            {
                id: 4,
                title: "Fast X",
                releaseDate: "2023-05-19",
                poster: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
                description: "Dom Toretto and his family are targeted by the vengeful son of drug kingpin Hernan Reyes."
            },
            {
                id: 5,
                title: "Guardians of the Galaxy Vol. 3",
                releaseDate: "2023-05-05",
                poster: "https://images.unsplash.com/photo-1485846234645-a62644f84728?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
                description: "Still reeling from the loss of Gamora, Peter Quill rallies his team to defend the universe and protect one of their own."
            }
        ];
        localStorage.setItem('upcomingMovies', JSON.stringify(upcomingMovies));
    }
}

// Get all data functions
function getMovies() {
    return JSON.parse(localStorage.getItem('movies') || '[]');
}

function getTheaters() {
    return JSON.parse(localStorage.getItem('theaters') || '[]');
}

function getSnacks() {
    return JSON.parse(localStorage.getItem('snacks') || '[]');
}

function getParking() {
    return JSON.parse(localStorage.getItem('parking') || '{}');
}

function getBookings() {
    return JSON.parse(localStorage.getItem('bookings') || '[]');
}

function getUpcomingMovies() {
    return JSON.parse(localStorage.getItem('upcomingMovies') || '[]');
}

// Save data functions
function saveMovies(movies) {
    localStorage.setItem('movies', JSON.stringify(movies));
}

function saveTheaters(theaters) {
    localStorage.setItem('theaters', JSON.stringify(theaters));
}

function saveSnacks(snacks) {
    localStorage.setItem('snacks', JSON.stringify(snacks));
}

function saveParking(parking) {
    localStorage.setItem('parking', JSON.stringify(parking));
}

function saveBookings(bookings) {
    localStorage.setItem('bookings', JSON.stringify(bookings));
}

function saveUpcomingMovies(movies) {
    localStorage.setItem('upcomingMovies', JSON.stringify(movies));
}

// Booking functions
function createBooking(bookingData) {
    const bookings = getBookings();
    const newBooking = {
        id: Date.now().toString(),
        ...bookingData,
        date: new Date().toISOString(),
        status: 'confirmed'
    };
    bookings.push(newBooking);
    saveBookings(bookings);
    return newBooking;
}

function generateQRCode(bookingId) {
    // Simple QR code generation using booking ID
    return `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${bookingId}`;
}

// Admin functions
function isAdmin() {
    return localStorage.getItem('isAdmin') === 'true';
}

function loginAdmin() {
    localStorage.setItem('isAdmin', 'true');
}

function logoutAdmin() {
    localStorage.removeItem('isAdmin');
}

// Initialize data on load
initializeData();